/*
SQLyog Ultimate v10.00 Beta1
MySQL - 5.5.5-10.1.29-MariaDB : Database - hrm
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`hrm` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `hrm`;

/*Table structure for table `admin_login` */

DROP TABLE IF EXISTS `admin_login`;

CREATE TABLE `admin_login` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Data for the table `admin_login` */

insert  into `admin_login`(`id`,`username`,`password`) values (1,'rakesh@gmail.com','123');

/*Table structure for table `awards` */

DROP TABLE IF EXISTS `awards`;

CREATE TABLE `awards` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Award_name` varchar(30) DEFAULT NULL,
  `Gift` varchar(30) DEFAULT NULL,
  `Cash_price` varchar(30) DEFAULT NULL,
  `Employee` varchar(30) DEFAULT NULL,
  `Month` varchar(30) DEFAULT NULL,
  `Year` varchar(30) DEFAULT NULL,
  `Email` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

/*Data for the table `awards` */

insert  into `awards`(`id`,`Award_name`,`Gift`,`Cash_price`,`Employee`,`Month`,`Year`,`Email`) values (1,'Employee of the Month','Mobile','20000','Rakesh','june','2013','rakesh@gmail.com'),(2,'Perfect Attendance','Gold','5000','Ram','july','2013','Ram@gmail.com'),(3,'Top performer','Silver','60000','Rakesh','October','2014','rakesh@gmail.com');

/*Table structure for table `department` */

DROP TABLE IF EXISTS `department`;

CREATE TABLE `department` (
  `d_id` int(11) NOT NULL AUTO_INCREMENT,
  `dept_name` varchar(30) DEFAULT NULL,
  `dept_design` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`d_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

/*Data for the table `department` */

insert  into `department`(`d_id`,`dept_name`,`dept_design`) values (7,'Android Development','Java Developer'),(8,'Human Resource','Manager'),(9,'Software Development','Java Develpoer');

/*Table structure for table `leave` */

DROP TABLE IF EXISTS `leave`;

CREATE TABLE `leave` (
  `Lid` int(20) NOT NULL AUTO_INCREMENT,
  `Email` varchar(30) DEFAULT NULL,
  `Leave_date` varchar(30) DEFAULT NULL,
  `Leave_type` varchar(30) DEFAULT NULL,
  `Reason` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`Lid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `leave` */

/*Table structure for table `project` */

DROP TABLE IF EXISTS `project`;

CREATE TABLE `project` (
  `Pid` int(20) NOT NULL AUTO_INCREMENT,
  `Pname` varchar(30) DEFAULT NULL,
  `Ename` varchar(30) DEFAULT NULL,
  `Department` varchar(30) DEFAULT NULL,
  `Duration` varchar(30) DEFAULT NULL,
  `Sdate` varchar(30) DEFAULT NULL,
  `Edate` varchar(30) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL,
  `status` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`Pid`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

/*Data for the table `project` */

insert  into `project`(`Pid`,`Pname`,`Ename`,`Department`,`Duration`,`Sdate`,`Edate`,`email`,`status`) values (8,'BMS','Rakesh ','Android developent','3 ','2018-04-08','2018-07-08','rakesh@gmail.com','pending'),(9,'E Services','Rakesh ','Software Development','3 ','2018-11-30','2019-02-28','rakesh@gmail.com','pending');

/*Table structure for table `registration` */

DROP TABLE IF EXISTS `registration`;

CREATE TABLE `registration` (
  `Rid` int(11) NOT NULL AUTO_INCREMENT,
  `Full_Name` varchar(50) NOT NULL,
  `Father_name` varchar(30) DEFAULT NULL,
  `Dob` varchar(30) NOT NULL,
  `Gender` varchar(10) NOT NULL,
  `Mobile_Number` varchar(20) DEFAULT NULL,
  `Local_Address` varchar(200) DEFAULT NULL,
  `Permanent_Address` varchar(200) DEFAULT NULL,
  `Department` varchar(20) NOT NULL,
  `Designation` varchar(20) NOT NULL,
  `Joining_Date` varchar(50) NOT NULL,
  `Current_Salary` varchar(20) NOT NULL,
  `Account_Name` varchar(30) NOT NULL,
  `Account_Number` varchar(20) NOT NULL,
  `Bank` varchar(50) NOT NULL,
  `IFSC` varchar(20) NOT NULL,
  `PAN` varchar(20) DEFAULT NULL,
  `Branch` varchar(20) NOT NULL,
  `Email` varchar(30) DEFAULT NULL,
  `Password` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`Rid`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

/*Data for the table `registration` */

insert  into `registration`(`Rid`,`Full_Name`,`Father_name`,`Dob`,`Gender`,`Mobile_Number`,`Local_Address`,`Permanent_Address`,`Department`,`Designation`,`Joining_Date`,`Current_Salary`,`Account_Name`,`Account_Number`,`Bank`,`IFSC`,`PAN`,`Branch`,`Email`,`Password`) values (6,'Rakesh','Gauri Shankar Prasad','2018-02-16','male','8950775733','Hisar','Bermiok Tokal','Android Development','Java Developer','2018-03-23','500000','Rakesh','15487878978','IDBI','BKID1146','RK10255','Singtam','rakesh@gmail.com','ra2120580'),(7,'Ram','Rahul','2018-01-18','male','9012548855','Patna','Delhi','Human Resource','Manager','2018-02-23','2000000','Ram','5200004546554','SBI','SB2252255','R1025555','Patna','Ram@gmail.com','123456');

/*Table structure for table `user_project` */

DROP TABLE IF EXISTS `user_project`;

CREATE TABLE `user_project` (
  `upid` int(11) NOT NULL AUTO_INCREMENT,
  `Pname` varchar(30) DEFAULT NULL,
  `Ename` varchar(30) DEFAULT NULL,
  `Department` varchar(30) DEFAULT NULL,
  `Duration` varchar(30) DEFAULT NULL,
  `Sdate` varchar(30) DEFAULT NULL,
  `Edate` varchar(30) DEFAULT NULL,
  `Email` varchar(30) DEFAULT NULL,
  `status` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`upid`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

/*Data for the table `user_project` */

insert  into `user_project`(`upid`,`Pname`,`Ename`,`Department`,`Duration`,`Sdate`,`Edate`,`Email`,`status`) values (2,'BMS','Rakesh ','Android developent','6','2018-12-01','2018-05-31','rakesh@gmail.com','verified'),(3,'E Services','Rakesh ','Software Development','6','2018-12-01','2018-05-31','rakesh@gmail.com','verified');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
