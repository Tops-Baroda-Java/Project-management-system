package com.model;

public class Loginmodel {

	
	private int userid;
	
	private String Name,Father_name,DOB,Gender,Phone,Local_Add,Per_Add,Email_id,Acc_pass;
	
	
	private String Company_detail_id,c_department,c_designation,c_DOB,c_joining_Sal;
	
	
	private String A_name,b_ACC_Num,b_Bank_nam,b_IFSC_code,b_PAN_Num,b_BRANCH;


	public int getUserid() {
		return userid;
	}


	public String getEmail_id() {
		return Email_id;
	}


	public void setEmail_id(String email_id) {
		Email_id = email_id;
	}


	public void setUserid(int userid) {
		this.userid = userid;
	}


	public String getName() {
		return Name;
	}


	public void setName(String name) {
		Name = name;
	}


	public String getFather_name() {
		return Father_name;
	}


	public void setFather_name(String father_name) {
		Father_name = father_name;
	}


	public String getDOB() {
		return DOB;
	}


	public void setDOB(String dOB) {
		DOB = dOB;
	}


	public String getGender() {
		return Gender;
	}


	public void setGender(String gender) {
		Gender = gender;
	}


	public String getPhone() {
		return Phone;
	}


	public void setPhone(String phone) {
		Phone = phone;
	}


	public String getLocal_Add() {
		return Local_Add;
	}


	public void setLocal_Add(String local_Add) {
		Local_Add = local_Add;
	}


	public String getPer_Add() {
		return Per_Add;
	}


	public void setPer_Add(String per_Add) {
		Per_Add = per_Add;
	}


	

	public String getAcc_pass() {
		return Acc_pass;
	}


	public void setAcc_pass(String acc_pass) {
		Acc_pass = acc_pass;
	}


	public String getCompany_detail_id() {
		return Company_detail_id;
	}


	public void setCompany_detail_id(String company_detail_id) {
		Company_detail_id = company_detail_id;
	}


	public String getC_department() {
		return c_department;
	}


	public void setC_department(String c_department) {
		this.c_department = c_department;
	}


	public String getC_designation() {
		return c_designation;
	}


	public void setC_designation(String c_designation) {
		this.c_designation = c_designation;
	}


	public String getC_DOB() {
		return c_DOB;
	}


	public void setC_DOB(String c_DOB) {
		this.c_DOB = c_DOB;
	}


	public String getC_joining_Sal() {
		return c_joining_Sal;
	}


	public void setC_joining_Sal(String c_joining_Sal) {
		this.c_joining_Sal = c_joining_Sal;
	}


	public String getA_name() {
		return A_name;
	}


	public void setA_name(String A_name) {
		this.A_name = A_name;
	}


	public String getB_ACC_Num() {
		return b_ACC_Num;
	}


	public void setB_ACC_Num(String b_ACC_Num) {
		this.b_ACC_Num = b_ACC_Num;
	}


	public String getB_Bank_nam() {
		return b_Bank_nam;
	}


	public void setB_Bank_nam(String b_Bank_nam) {
		this.b_Bank_nam = b_Bank_nam;
	}


	public String getB_IFSC_code() {
		return b_IFSC_code;
	}


	public void setB_IFSC_code(String b_IFSC_code) {
		this.b_IFSC_code = b_IFSC_code;
	}


	public String getB_PAN_Num() {
		return b_PAN_Num;
	}


	public void setB_PAN_Num(String b_PAN_Num) {
		this.b_PAN_Num = b_PAN_Num;
	}


	public String getB_BRANCH() {
		return b_BRANCH;
	}


	public void setB_BRANCH(String b_BRANCH) {
		this.b_BRANCH = b_BRANCH;
	}
	
	
	
	
	
}
