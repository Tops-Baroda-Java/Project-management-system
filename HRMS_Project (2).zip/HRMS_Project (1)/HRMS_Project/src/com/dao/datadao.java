package com.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.model.Award_model;
import com.model.Leave_model;
import com.model.Loginmodel;
import com.model.Project_model;
import com.model.admin_login;
import com.model.department_insert;
import com.mysql.jdbc.Connection;
import ccm.util.Dbconnection;

public class datadao implements datadaoi 
{
	Connection con;
	@Override
	public String insert(Loginmodel model) {

		con= Dbconnection.gConnection();
		String s="";
		
		try {
			
			PreparedStatement psmt=con.prepareStatement("insert into registration(Full_Name,Father_name,Dob,Gender,Mobile_Number,Local_Address,Permanent_Address,Department,Designation,Joining_Date,Current_Salary,Account_Name,Account_Number,Bank,IFSC,PAN,Branch,Email,Password) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
	
			psmt.setString(1, model.getName());
			
			psmt.setString(2, model.getFather_name());
			psmt.setString(3, model.getDOB());
			
			psmt.setString(4, model.getGender());
			psmt.setString(5, model.getPhone());
			psmt.setString(6, model.getLocal_Add());
			psmt.setString(7, model.getPer_Add());
			psmt.setString(8, model.getC_department());
			psmt.setString(9, model.getC_designation());
			psmt.setString(10, model.getC_DOB());
			psmt.setString(11, model.getC_joining_Sal());
			psmt.setString(12, model.getA_name());
			psmt.setString(13, model.getB_ACC_Num());
			psmt.setString(14, model.getB_Bank_nam());
			psmt.setString(15, model.getB_IFSC_code());
			psmt.setString(16, model.getB_PAN_Num());
			psmt.setString(17, model.getB_BRANCH());
			psmt.setString(18,model.getEmail_id());
			psmt.setString(19, model.getAcc_pass());
					
        	int i=psmt.executeUpdate();
        	
        	if(i>0){
    			s="inserted";
    		}
    		} catch (SQLException e) {
    			// TODO Auto-generated catch block
    			e.printStackTrace();
    		}
    	
			return s;
    	}
	
	@Override
	public List<Loginmodel> showall() {
		
		try {
			  		 con = Dbconnection.gConnection();
			  		PreparedStatement  psmt=con.prepareStatement("select * from registration");
			  		List<Loginmodel>  al=new ArrayList<Loginmodel>();
			  		ResultSet rs=psmt.executeQuery();
			  		Loginmodel model;
			  		while(rs.next())
			  		{
			
			  			model=new Loginmodel();
			  			model.setUserid(rs.getInt("Rid"));
			  			model.setName(rs.getString("Full_name"));
			  			model.setFather_name(rs.getString("Father_name"));
			  			model.setDOB(rs.getString("Dob"));
			  			model.setGender(rs.getString("gender"));
			  			model.setPhone(rs.getString("Mobile_Number"));
			  		/*	model.setPhone(rs.getString("Local_Address"));
			  			model.setPhone(rs.getString("Permanent_Address")); 
			  			model.setPhone(rs.getString("Department"));
			  			model.setUserid(rs.getInt("Designation"));
			  			model.setName(rs.getString("Joining_Date"));
			  			model.setFather_name(rs.getString("Current_Salary"));
			  			model.setDOB(rs.getString("Account_Name"));
			  			model.setGender(rs.getString("Account_Number"));
			  			model.setPhone(rs.getString("Bank"));
			  			model.setPhone(rs.getString("IFSC"));
			  			model.setPhone(rs.getString("PAN"));
			  			model.setPhone(rs.getString("Branch")); */
			
			  			al.add(model);
		           }
			           return al;	
			           
		} catch (SQLException e) {
			e.printStackTrace();
		}	
		return null;
	}
	
	
	@Override
	public admin_login validate(String username, String password) {

		 {
			con=Dbconnection.gConnection();
			
			PreparedStatement psmt;
			try {
				psmt = con.prepareStatement("select * from admin_login where username=? and password=?");
				
				psmt.setString(1, username);
				psmt.setString(2, password);
			
				ResultSet rs=psmt.executeQuery();
				
				admin_login ad=null;
		
					while(rs.next())
					{
						
						
						ad=new admin_login();
						ad.setUsername(rs.getString("username"));
						ad.setPassword(rs.getString("password"));
				
					}
					
					return ad;
					
		    }   catch (SQLException e) 
				{
					e.printStackTrace();
				}
	
		}
	
		return null;
	}
	
	@Override
	public String dept(department_insert model) {
		// TODO Auto-generated method stub
		
		con=Dbconnection.gConnection();
		String s="";
		
			
			PreparedStatement psmt;
			try {
				psmt = con.prepareStatement("insert into department(dept_name,dept_design) values(?,?)");
				psmt.setString(1, model.getDept_name());
				
				psmt.setString(2, model.getDesignation());
				
			    int i= 	psmt.executeUpdate();
			    
			    if(i>0)
				{
					return s="done";
				}

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		return s;
	}

	

	@Override
	public String Awards(Award_model model) {
		
		con=Dbconnection.gConnection();
		String s="";
		try {
			
			PreparedStatement psmt=con.prepareStatement("insert into awards(Award_name,Gift,Cash_price,Employee,Month,Year,Email) values(?,?,?,?,?,?,?)");
			psmt.setString(1,model.getAward_name());
			psmt.setString(2, model.getGift());
			psmt.setString(3, model.getCost_price());
			psmt.setString(4, model.getEmployee_name());
			psmt.setString(5, model.getMonth());
			psmt.setString(6, model.getYear());
			//psmt.setInt(7, 4);
			psmt.setString(7, model.getEmail_id());
			int i= 	psmt.executeUpdate();
			
			if(i>0)
			{
				return s="done";
			}
			
		} 
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return s;
	}

	@Override
	public List<department_insert> show_dept() {
		// TODO Auto-generated method stub
		
		 con = Dbconnection.gConnection();
	  		PreparedStatement psmt;
			try {
				psmt = con.prepareStatement("select * from department");
				List<department_insert>  all=new ArrayList<department_insert>();
		  		ResultSet rs=psmt.executeQuery();
		  		department_insert model;
		  		
		  		while(rs.next())
		  		{
		  			model=new department_insert();
		  			
		  			model.setDept_id(rs.getInt("d_id"));
		  			model.setDept_name(rs.getString("dept_name"));
		  			model.setDesignation(rs.getString("dept_design"));
		  			
		  			all.add(model);
		  		}
		  		return all;
		  		
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	  		
		return null;
	}

	@Override
	public List<Award_model> show_awards() {
		
		con=Dbconnection.gConnection();
		try {
			PreparedStatement psmt = con.prepareStatement("select * from awards");
		//PreparedStatement	psmt1 =con.prepareStatement("select Rid from registration");
			List<Award_model> al = new ArrayList<Award_model>();
			ResultSet rs= psmt.executeQuery();
			
			Award_model model;
			
			while(rs.next())
			{
				model=new Award_model();
				model.setId(rs.getInt("id"));
				model.setAward_name(rs.getString("Award_name"));
				model.setGift(rs.getString("Gift"));
				model.setCost_price(rs.getString("Cash_price"));
				model.setEmployee_name(rs.getString("Employee"));
				model.setMonth(rs.getString("Month"));
				model.setYear(rs.getString("Year"));
				
				al.add(model);
			}
			
			return al;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// TODO Auto-generated method stub
		return null;
	}
	
	@Override
	public Loginmodel edit(int Rid) {
		// TODO Auto-generated method stub
		
		
			
			try {
				con=Dbconnection.gConnection();
				PreparedStatement psmt;
				psmt = con.prepareStatement("select * from registration where Rid=?");
				psmt.setInt(1, Rid);
				
				ResultSet rs=	psmt.executeQuery();
				Loginmodel model=null;
				while(rs.next())
				{
					
					
					model=new Loginmodel();
					model.setUserid(rs.getInt("Rid"));
					model.setName(rs.getString("Full_Name"));
					model.setFather_name(rs.getString("Father_name"));
					
					
					model.setDOB(rs.getString("Dob"));
					model.setGender(rs.getString("Gender"));
					model.setPhone(rs.getString("Mobile_Number"));
					
				}
				return model;
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		return null;
	}

	@Override
	public String update(Loginmodel model) {
		// TODO Auto-generated method stub
	
		
		con= Dbconnection.gConnection();
		
		
		try {
			PreparedStatement psmt=con.prepareStatement("update registration set Full_Name=?,Father_name=?,Dob=?,Gender=?,Mobile_Number=? where Rid=?");
		
		
		psmt.setString(1,model.getName());
		psmt.setString(2, model.getFather_name());
		
		
		psmt.setString(3, model.getDOB());
		
		psmt.setString(4, model.getGender());
		psmt.setString(5, model.getPhone());
		
		
		psmt.setInt(6, model.getUserid());
		int i=    psmt.executeUpdate();
		if(i>0)
		{
			return "done";
		}
		
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

		
		return null;
	}

	@Override
	public String delete(int id) {
	
		con= Dbconnection.gConnection();
		
		try {
			PreparedStatement psmt=con.prepareStatement("delete from registration where Rid=?");
			psmt.setInt(1,id);
			
			int i=psmt.executeUpdate();
			if(i>0)
			{
				
				return "done";
				
				
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
		return null;
	}
	

	@Override
	public department_insert d_edit(int d_id) {
		
		con=Dbconnection.gConnection();
		try {
			PreparedStatement psmt = con.prepareStatement("select * from department where d_id=?");	
			psmt.setInt(1, d_id);
			
			ResultSet rs=	psmt.executeQuery();
			department_insert model=null;
			
			while(rs.next())
			{
				model=new department_insert();
	  			
	  			model.setDept_id(rs.getInt("d_id"));
	  			model.setDept_name(rs.getString("dept_name"));
	  			model.setDesignation(rs.getString("dept_design"));
			}
			return model;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return null;
	}

	@Override
	public String d_update(department_insert model) {
		
		con= Dbconnection.gConnection();
		
				PreparedStatement psmt;
				try {
					
					psmt = con.prepareStatement("update department set dept_name=?,dept_design=? where d_id=?");
					psmt.setString(1,model.getDept_name());
					psmt.setString(2, model.getDesignation());
					psmt.setInt(3,model.getDept_id());
					
					int i=    psmt.executeUpdate();
					if(i>0)
					{
						return "done";
					}
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

		return null;
	}

	@Override
	public String d_delete(int d_id) {
		con= Dbconnection.gConnection();
		try {
			PreparedStatement psmt = con.prepareStatement("delete from department where d_id=?");
			psmt.setInt(1,d_id );
			int i=psmt.executeUpdate();
			if(i>0)
			{
				return "done";
			
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	//for award view/update and delete 
	@Override
	public Award_model a_edit(int id) {
		
		con=Dbconnection.gConnection();
		try {
			PreparedStatement psmt = con.prepareStatement("select * from awards where id=?");
			psmt.setInt(1, id);
			ResultSet rs= psmt.executeQuery();
			Award_model model=null;
			
			while(rs.next())
			{
				model=new Award_model();
				model.setId(rs.getInt("id"));
				model.setAward_name(rs.getString("Award_name"));
				model.setGift(rs.getString("Gift"));
				model.setCost_price(rs.getString("Cash_price"));
				model.setEmployee_name(rs.getString("Employee"));
				model.setMonth(rs.getString("Month"));
				model.setYear(rs.getString("Year"));
				
		
			}
			
			return model;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
	}

	@Override
	public String a_update(Award_model model) {
		
		con= Dbconnection.gConnection();
		
		PreparedStatement psmt;
		try {
			
			psmt = con.prepareStatement("update awards set Award_name=?,Gift=?,Cash_price=?,Employee=?,Month=?,Year=? where id=?");
			psmt.setString(1,model.getAward_name());
			psmt.setString(2, model.getGift());
			psmt.setString(3,model.getCost_price());
			psmt.setString(4, model.getEmployee_name());
			psmt.setString(5,model.getMonth());
			psmt.setString(6,model.getYear());
			psmt.setInt(7,model.getId());
			
			int i=   psmt.executeUpdate();
			if(i>0)
			{
				return "done";
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
	}

	@Override
	public String a_delete(int id) {
		
		con= Dbconnection.gConnection();
		try {
			PreparedStatement psmt = con.prepareStatement("delete from awards where id=?");
			psmt.setInt(1,id);
			int i=psmt.executeUpdate();
			if(i>0)
			{
				return "done";
			
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
	}

	@Override
	public String project_insert(Project_model model) {
		con=Dbconnection.gConnection();
		String s="";
		try {
			PreparedStatement psmt=con.prepareStatement("insert into project(Pname,Ename,Department,Duration,Sdate,Edate,email,status)values(?,?,?,?,?,?,?,?)");
		
			PreparedStatement psmt1=con.prepareStatement("insert into user_project(Pname,Ename,Department,Duration,Sdate,Edate,email,status)values(?,?,?,?,?,?,?,?)");
			
			
			
			psmt.setString(1, model.getPname());
			psmt.setString(2, model.getEname());
			psmt.setString(3, model.getDepartment());
			psmt.setString(4, model.getDuration());
			psmt.setString(5, model.getStartDate());
			psmt.setString(6, model.getEnddate());
			psmt.setString(7,model.getEmail());
			psmt.setString(8,model.getStatus());
			
			
			
			psmt1.setString(1, model.getPname());
			psmt1.setString(2, model.getEname());
			psmt1.setString(3, model.getDepartment());
			psmt1.setString(4, model.getDuration());
			psmt1.setString(5, model.getStartDate());
			psmt1.setString(6, model.getEnddate());
			psmt1.setString(7,model.getEmail());
			psmt1.setString(8,model.getStatus());
			
			
			
			int i=psmt.executeUpdate();
			int j=psmt1.executeUpdate();
			
			if(i>0)
			{
				return s= "done";
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return s;
	}

	@Override
	public List<Project_model> show_project() {
		con=Dbconnection.gConnection();
		try {
			PreparedStatement psmt =con.prepareStatement("select * from project");
			ResultSet rs=psmt.executeQuery();
			List<Project_model> Plist = new ArrayList<Project_model>();
			Project_model model;
			while(rs.next())
			{
				model=new Project_model();
				model.setPid(rs.getInt("Pid"));
				model.setPname(rs.getString("Pname"));
				model.setEname(rs.getString("Ename"));
				model.setDepartment(rs.getString("Department"));
				model.setDuration(rs.getString("Duration"));
				model.setStartDate(rs.getString("Sdate"));
				model.setEnddate(rs.getString("Edate"));
				
				Plist.add(model);
			}
			return Plist;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	
	@Override //fetch data from database for updation.
	public Project_model p_edit(int Pid) {
		con=Dbconnection.gConnection();
		try {
			PreparedStatement psmt= con.prepareStatement("select * from project where Pid=?");
			psmt.setInt(1, Pid);
			ResultSet rs=psmt.executeQuery();
			Project_model model=null;
			while(rs.next())
			{
				model=new Project_model();
				model.setPid(rs.getInt("Pid"));
				model.setPname(rs.getString("Pname"));
				model.setEname(rs.getString("Ename"));
				model.setDepartment(rs.getString("Department"));
				model.setDuration(rs.getString("Duration"));
				model.setStartDate(rs.getString("Sdate"));
				model.setEnddate(rs.getString("Edate"));
			}
			
			return model;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
	}

	//update data in database
	@Override
	public String p_update(Project_model model) {
		
        con= Dbconnection.gConnection();
		
		PreparedStatement psmt;
		try {
			
			psmt = con.prepareStatement("update project set Pname=?,Ename=?,Department=?,Duration=?,Sdate=?,Edate=? where Pid=?");
			psmt.setString(1,model.getPname());
			psmt.setString(2, model.getEname());
			psmt.setString(3,model.getDepartment());
			psmt.setString(4, model.getDuration());
			psmt.setString(5,model.getStartDate());
			psmt.setString(6,model.getEnddate());
			psmt.setInt(7,model.getPid());
			
			int i=   psmt.executeUpdate();
			if(i>0)
			{
				return "done";
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	
	@Override
	public String p_delete(int Pid) {
		
		con= Dbconnection.gConnection();
		try {
			PreparedStatement psmt = con.prepareStatement("delete from project where Pid=?");
			psmt.setInt(1,Pid);
			int i=psmt.executeUpdate();
			if(i>0)
			{
				return "done";
			
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	//User Module................................
	@Override
	public Loginmodel user_validate(String user, String pass) {
		
		con=Dbconnection.gConnection();
		try {
			PreparedStatement psmt= con.prepareStatement("select * from registration where Email=? and Password=?");
			psmt.setString(1, user);
			psmt.setString(2, pass);
			ResultSet rs = psmt.executeQuery();
			Loginmodel model=null;
			while(rs.next())
			{
				model=new Loginmodel();
				model.setEmail_id(rs.getString("Email"));
				model.setAcc_pass(rs.getString("Password"));
			}
			return model;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// TODO Auto-generated method stub
		return null;
	}
	
	


	@Override
	public Loginmodel User_info(String email) {
		
		con=Dbconnection.gConnection();
		PreparedStatement psmt;
		try {
			psmt = con.prepareStatement("select * from registration where Email=?");
			psmt.setString(1, email);
			
			ResultSet rs = psmt.executeQuery();
			Loginmodel model=null;
			while(rs.next())
			{
				
				
				model=new Loginmodel();
	  			model.setUserid(rs.getInt("Rid"));
	  			model.setName(rs.getString("Full_name"));
	  			model.setFather_name(rs.getString("Father_name"));
	  			model.setDOB(rs.getString("Dob"));
	  			model.setGender(rs.getString("gender"));
	  			model.setPhone(rs.getString("Mobile_Number"));
	  			model.setPhone(rs.getString("Local_Address"));
	  			model.setPhone(rs.getString("Permanent_Address")); 
	  			model.setPhone(rs.getString("Department"));
	  			model.setUserid(rs.getInt("Designation"));
	  			model.setName(rs.getString("Joining_Date"));
	  			model.setFather_name(rs.getString("Current_Salary"));
	  			model.setDOB(rs.getString("Account_Name"));
	  			model.setGender(rs.getString("Account_Number"));
	  			model.setPhone(rs.getString("Bank"));
	  			model.setPhone(rs.getString("IFSC"));
	  			model.setPhone(rs.getString("PAN"));
	  			model.setPhone(rs.getString("Branch")); 
	  			model.setEmail_id(rs.getString("Email"));
	
			}
			return model;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return null;
	}

	@Override
	public String leave_insert(Leave_model model) {
		 con=Dbconnection.gConnection();
		 try {
			PreparedStatement psmt=con.prepareStatement("insert into leave(Email,Leave_date,Leave_type,Reason)values(?,?,?,?)");
		    psmt.setString(1, model.getEmail());
			psmt.setString(2, model.getDate());
		    psmt.setString(3, model.getLeave_type());
		    psmt.setString(4, model.getReason());
		    int a=psmt.executeUpdate();
		    
		    if(a>0)
		    {
		    	return "done";
		    }
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public List<Leave_model> show_Leave() {
		
		con=Dbconnection.gConnection();
		try {
			PreparedStatement psmt =con.prepareStatement("select * from leave");
			ResultSet rs=psmt.executeQuery();
			List<Leave_model> list = new ArrayList<Leave_model>();
			Leave_model model;
			while(rs.next())
			{
				model=new Leave_model();
				model.setLid(rs.getInt("Lid"));
				model.setEmail(rs.getString("Email"));
				model.setDate(rs.getString("Leave_date"));
				model.setLeave_type(rs.getString("Leave_type"));
				model.setReason(rs.getString("Reason"));
				
				
				list.add(model);
			}
			return list;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public Project_model projectdata(String email) {
		// TODO Auto-generated method stub
		con=Dbconnection.gConnection();
		PreparedStatement psmt;
		try {
			psmt = con.prepareStatement("select * from project where email=?");
			psmt.setString(1, email);
			
		ResultSet rs=	psmt.executeQuery();
		Project_model model=null;
			while(rs.next())
			
				
			{
				
				model=new Project_model();
				model.setEname(rs.getString("Ename"));
				model.setEmail(rs.getString("email"));
				model.setStatus(rs.getString("status"));
						model.setPid(rs.getInt("Pid"));
						model.setPname(rs.getString("Pname"));
						model.setEname(rs.getString("Ename"));
						model.setDepartment(rs.getString("Department"));
						model.setDuration(rs.getString("Duration"));
						model.setStartDate(rs.getString("Sdate"));
						model.setEnddate(rs.getString("Edate"));
			}
			
			return model;
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		
		
		
		
		
		
		
		return null;
	}

	@Override
	public String usertask_update(Project_model model) {
		// TODO Auto-generated method stub
	
		
		
		
		  con= Dbconnection.gConnection();
			
			PreparedStatement psmt;
			try {
				
				psmt = con.prepareStatement("update user_project set Duration=?,Sdate=?,Edate=? where email=?");
			
				psmt.setString(1, model.getDuration());
				psmt.setString(2,model.getStartDate());
				psmt.setString(3,model.getEnddate());
			psmt.setString(4, model.getEmail());
				
				int i=   psmt.executeUpdate();
				if(i>0)
				{
					return "done";
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		
		
		
		return null;
	}

	@Override
	public List<Project_model> show_task() {

		con=Dbconnection.gConnection();
		try {
			PreparedStatement psmt =con.prepareStatement("select * from user_project");
			ResultSet rs=psmt.executeQuery();
			List<Project_model> list=new ArrayList<Project_model>();
			Project_model model=null;
			while(rs.next())
			{
				model=new Project_model();
				model.setPid(rs.getInt("upid"));
				model.setPname(rs.getString("Pname"));
				model.setEname(rs.getString("Ename"));
				model.setDepartment(rs.getString("Department"));
				model.setDuration(rs.getString("Duration"));
				model.setStartDate(rs.getString("Sdate"));
				model.setEnddate(rs.getString("Edate"));
				model.setEmail(rs.getString("Email"));
				model.setStatus(rs.getString("status"));
				
				list.add(model);
			}
			return list;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public Project_model task_update(String email) {
		// TODO Auto-generated method stub
		
		
		con=Dbconnection.gConnection();
		PreparedStatement psmt;
		try {
			psmt = con.prepareStatement("select * from user_project where Email=?");
			psmt.setString(1, email);
			Project_model model=null;
			
ResultSet rs=			psmt.executeQuery();
			while(rs.next())
			{
				
				model=new Project_model();
				model.setPid(rs.getInt("upid"));
				model.setPname(rs.getString("Pname"));
				model.setEname(rs.getString("Ename"));
				model.setDepartment(rs.getString("Department"));
				model.setDuration(rs.getString("Duration"));
				model.setStartDate(rs.getString("Sdate"));
				model.setEnddate(rs.getString("Edate"));
				model.setEmail(rs.getString("Email"));
				model.setStatus(rs.getString("status"));
				
			}
		return model;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		
		return null;
	

	
		
		
		
		
		
		
		
		
		
		
		
	}

	@Override
	public String update(Project_model model) {
		// TODO Auto-generated method stub
	
		
		
		
		
		con=Dbconnection.gConnection();
		try {
			PreparedStatement psmt1=con.prepareStatement("update user_project set status=? where Email=?");
			PreparedStatement psmt=con.prepareStatement("insert into user_report(Pname,Ename,Department,Duration,Assigntime,Sdate,Edate,email,status,grade)values(?,?,?,?,?,?,?,?,?,?)");
		
			

			psmt.setString(1, model.getPname());
			psmt.setString(2, model.getEname());
			psmt.setString(3, model.getDepartment());
			psmt.setString(4, model.getDuration());
			psmt.setString(5, model.getAssigntime());
			psmt.setString(6, model.getStartDate());
			psmt.setString(7, model.getEnddate());
			psmt.setString(8,model.getEmail());
			psmt.setString(9,model.getStatus());
			psmt.setString(10, model.getGrade());
			
			
			
			
		psmt1.setString(1, model.getStatus());
		psmt1.setString(2, model.getEmail());
int i=		psmt1.executeUpdate();
if(i>0)
{
	return "done";
}
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		return null;
	}

	@Override
	public String report_insert(Project_model model) {
		// TODO Auto-generated method stub
		
		
		
		con=Dbconnection.gConnection();
		
		try {
			PreparedStatement psmt=con.prepareStatement("insert into user_report(Pname,Ename,Department,Duration,Assigntime,Sdate,Edate,email,status,grade)values(?,?,?,?,?,?,?,?,?,?)");
		
			
			
			
			
			psmt.setString(1, model.getPname());
			psmt.setString(2, model.getEname());
			psmt.setString(3, model.getDepartment());
			psmt.setString(4, model.getDuration());
			psmt.setString(5, model.getAssigntime());
			psmt.setString(6, model.getStartDate());
			psmt.setString(7, model.getEnddate());
			psmt.setString(8,model.getEmail());
			psmt.setString(9,model.getStatus());
			psmt.setString(10, model.getGrade());
			
			
	int i=		psmt.executeUpdate();
			if(i>0)
			{
				return "done";
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
			
		
		
		
		return null;
		}
		
	}

	
	



