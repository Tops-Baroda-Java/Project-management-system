package com.dao;

import java.util.List;

import com.model.Award_model;
import com.model.Leave_model;
import com.model.Loginmodel;
import com.model.Project_model;
import com.model.admin_login;
import com.model.department_insert;

public interface datadaoi {

	public String insert(Loginmodel model);
	
     List<Loginmodel> showall();
	
	public admin_login validate(String username,String password);
	public Project_model projectdata(String email);

	public String dept(department_insert model);
	List<department_insert>show_dept();
	
	public String Awards(Award_model model);
	List<Award_model>show_awards();
	
	public Loginmodel edit(int Rid);
	public String update(Loginmodel model);
	public String delete(int id);
	
	//for department view/update and delete
	public department_insert d_edit(int d_id);
	public String d_update(department_insert model);
	public String d_delete(int d_id);
	
	//for award view/update and delete 
	public Award_model a_edit(int d_id);
	public String a_update(Award_model model);
	public String a_delete(int id);
	
	//admin Projects
	
	public String project_insert(Project_model model);
	List<Project_model>show_project();
	public Project_model p_edit(int Pid);
	public String p_update(Project_model model);
	public String p_delete(int Pid);
	
	public Loginmodel user_validate(String user,String pass);
	public Loginmodel User_info(String email);
	
	//Leave Application
	
	public String leave_insert(Leave_model model);
	List<Leave_model>show_Leave();
	
	
	
	
	
	
	//task
	public String usertask_update(Project_model model);
	List<Project_model>show_task();
	
	//public String task_update
	public Project_model task_update(String email);
	public String update(Project_model model);
	
	
	
	
	
	
	//report
	public String report_insert(Project_model model);
	
	
	
	
	
	
}
