package com.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.datadao;
import com.model.Award_model;


public class Award_update extends HttpServlet {
	private static final long serialVersionUID = 1L;
 
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String action=request.getParameter("action");
		
	if(action.equals("a_edit"))
	{
		String id= request.getParameter("userid");
		datadao dao = new datadao();
		Award_model model = dao.a_edit(Integer.parseInt(id));
		
		request.setAttribute("editdata2",model);
		RequestDispatcher rd=request.getRequestDispatcher("award_update.jsp");
		rd.forward(request, response);
	}
	else if(action.equals("Update"))
	{
		String id=request.getParameter("id1");
		System.out.println(id);
		String awardName=request.getParameter("awardName");
		String gift=request.getParameter("gift");
		String cashPrice=request.getParameter("cashPrice");
		String employee=request.getParameter("employee");
		String forMonth=request.getParameter("forMonth");
		String forYear=request.getParameter("forYear");
		
		
	     Award_model model=new Award_model();
		 model.setAward_name(awardName);
		 model.setGift(gift);
		 model.setCost_price(cashPrice);
		 model.setEmployee_name(employee);
		 model.setMonth(forMonth);
		 model.setYear(forYear);
		 model.setId(Integer.parseInt(id));
		 
		 datadao dao=new datadao();
		 String m= dao.a_update(model);
		 
		 if(m.equals("done"))
		 {
		
					RequestDispatcher rd=request.getRequestDispatcher("show_awards");
					rd.forward(request, response);
				
		 }
		
	}
	else
	{
		String id = request.getParameter("id");
		datadao dao = new datadao();
		String m=dao.a_delete(Integer.parseInt(id));
		if(m.equals("done"))
		{
			RequestDispatcher rd = request.getRequestDispatcher("show_awards");
			rd.forward(request, response);
		}
	}
	}

	
	

}
