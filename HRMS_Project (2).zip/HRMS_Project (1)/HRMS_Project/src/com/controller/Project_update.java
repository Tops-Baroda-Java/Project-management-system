package com.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.datadao;
import com.model.Project_model;


public class Project_update extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.getWriter().append("Served at: ").append(request.getContextPath());
		
		String action =request.getParameter("action");
		
		if(action.equals("Pedit"))
		{
			datadao dao =new datadao();
			String Projectid=request.getParameter("Projectid");
			Project_model model =dao.p_edit(Integer.parseInt(Projectid));
			
			request.setAttribute("Pdata",model);
			RequestDispatcher rd=request.getRequestDispatcher("Project_update.jsp");
			rd.forward(request, response);
		}
		
		else if(action.equals("Update"))
		{
			datadao dao = new datadao();
			Project_model model=new Project_model();
			String Pid=request.getParameter("Pid");
			String Pname=request.getParameter("projectName");
			String Ename=request.getParameter("employee");
			String Department=request.getParameter("department");
			String duration= request.getParameter("duration");
			String startDate=request.getParameter("startDate");
			String endDate=request.getParameter("endDate");
			
			model.setPname(Pname);
			model.setEname(Ename);
			model.setDepartment(Department);
			model.setDuration(duration);
			model.setStartDate(startDate);
			model.setEnddate(endDate);
			model.setPid(Integer.parseInt(Pid));
			
			String str=dao.p_update(model);
			
			if(str.equals("done"))
			{
				RequestDispatcher rd=request.getRequestDispatcher("Show_project");
				rd.forward(request, response);
			}
			
		}
		
		else
		{
			String Pid=request.getParameter("Pid");
			datadao dao=new datadao();
			String str = dao.p_delete(Integer.parseInt(Pid));
			if(str.equals("done"))
			{
				RequestDispatcher rd=request.getRequestDispatcher("Show_project");
				rd.forward(request, response);
			}
		}
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
