package com.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.datadao;
import com.model.Leave_model;

/**
 * Servlet implementation class Leave_Entry
 */
public class Leave_Entry extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String date=request.getParameter("date[0]");
		String leaveType=request.getParameter("leaveType[0]");
		String reason=request.getParameter("reason[0]");
		String Email=request.getParameter("email");
		
		Leave_model model = new Leave_model();
		model.setDate(date);
		model.setLeave_type(leaveType);
		model.setReason(reason);
		model.setEmail(Email);
		
		datadao dao = new datadao();
		String m=dao.leave_insert(model);
		
		if(m.equals("done"))
		{
			RequestDispatcher rd=request.getRequestDispatcher("Leave_show");
			rd.forward(request, response);
		}
		
		doGet(request, response);
	}

}
