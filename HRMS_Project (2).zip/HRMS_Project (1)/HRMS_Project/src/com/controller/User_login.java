package com.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dao.datadao;
import com.model.Loginmodel;

/**
 * Servlet implementation class User_login
 */
public class User_login extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public User_login() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 
		String email=request.getParameter("email");
		String password=request.getParameter("password");
		Loginmodel model= new Loginmodel();
		model.setEmail_id(email);
		model.setAcc_pass(password);
		datadao dao=new datadao();
	  model=     dao.user_validate(email, password);
	
	  
	  
	  HttpSession sess=request.getSession();
	  
	  sess.setAttribute("user_data", email);
	  
	  
	  if(model!=null)
	  {
		  
		  RequestDispatcher rd=request.getRequestDispatcher("empdashboard1.jsp");
		  rd.forward(request, response);
	  }
	  else
	  {
		  
		  RequestDispatcher rd=request.getRequestDispatcher("User_login.jsp");
		  rd.forward(request, response);
		  
	  }
		doGet(request, response);
	}

}
