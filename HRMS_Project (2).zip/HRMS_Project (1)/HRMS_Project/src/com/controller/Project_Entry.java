package com.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.datadao;
import com.model.Project_model;

/**
 * Servlet implementation class Project_Entry
 */
public class Project_Entry extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}
       
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String projectName=request.getParameter("projectName");
		String employeeName=request.getParameter("employee");
		String department=request.getParameter("department");
		String duration=request.getParameter("duration");
		String startDate=request.getParameter("startDate");
		String endDate=request.getParameter("endDate");
		String email=request.getParameter("email");
		String pstatus=request.getParameter("pstatus")
;		
		Project_model model = new Project_model();
		model.setPname(projectName);
		model.setEname(employeeName);
		model.setDepartment(department);
		model.setDuration(duration);
		model.setStartDate(startDate);
		model.setEnddate(endDate);
		model.setEmail(email);
		model.setStatus(pstatus);
		datadao dao =new datadao();
		String m=dao.project_insert(model);
		
		if(m.equals("done"))
		{
			RequestDispatcher rd=request.getRequestDispatcher("Show_project");
			rd.forward(request, response);
		}
		doGet(request, response);
		
	}

}
