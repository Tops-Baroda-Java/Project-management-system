package com.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.datadao;
import com.model.department_insert;


public class department_update extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String action=request.getParameter("action");
		if(action.equals("d_edit"))
		{
			String deptid=request.getParameter("deptid");
			datadao dao = new datadao();
			department_insert model=dao.d_edit(Integer.parseInt(deptid));
			
			request.setAttribute("editdata1", model);
			
			RequestDispatcher rd=request.getRequestDispatcher("department_update.jsp");
			rd.forward(request, response);
		}
		else if(action.equals("Update"))
		{
			String dept_name=request.getParameter("deptName");
			String dept_design=request.getParameter("designation[0]");
			String d_id=request.getParameter("did");
			
			department_insert model = new department_insert();
			model.setDept_name(dept_name);
			model.setDesignation(dept_design);
			model.setDept_id(Integer.parseInt(d_id));
			
			datadao dao=new datadao();
		    String m=dao.d_update(model);
			if(m.equals("done"))
			{
			
				RequestDispatcher rd=request.getRequestDispatcher("show_dept");
				rd.forward(request, response);
			}
			
		}
		
		else
		{
			String deptid=request.getParameter("deptid");
			datadao  dao=new datadao();
		   String s=dao.d_delete(Integer.parseInt(deptid));
			if(s.equals("done"))
			{
				
				
				RequestDispatcher rd=request.getRequestDispatcher("show_dept");
				rd.forward(request, response);
				
			}
			
		}
		
	}

	
}
