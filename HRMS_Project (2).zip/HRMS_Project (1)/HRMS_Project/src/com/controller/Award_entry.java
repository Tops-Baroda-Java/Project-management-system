package com.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.datadao;
import com.model.Award_model;

public class Award_entry extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}   
    
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String awardName=request.getParameter("awardName");
		String gift=request.getParameter("gift");
		String cashPrice=request.getParameter("cashPrice");
		String employee=request.getParameter("employee");
		String email=request.getParameter("email");
		String forMonth=request.getParameter("forMonth");
		String forYear=request.getParameter("forYear");
		
		Award_model model = new Award_model();
		model.setAward_name(awardName);
		model.setGift(gift);
		model.setCost_price(cashPrice);
		model.setEmployee_name(employee);
		model.setEmail_id(email);
		model.setMonth(forMonth);
		model.setYear(forYear);
		
		datadao dao = new datadao();
		String str=dao.Awards(model);
		if(str.equals("done"))
		{
			RequestDispatcher rd=request.getRequestDispatcher("show_awards");
			rd.forward(request, response);
		}
		doGet(request, response);
	}

}
