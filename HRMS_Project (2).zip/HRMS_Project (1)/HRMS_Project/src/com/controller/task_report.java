package com.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.datadao;
import com.model.Project_model;


/**
 * Servlet implementation class task_report
 */
public class task_report extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public task_report() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		
		
		
		String name=request.getParameter("action");
		if(name.equals("update"))
		{
			String projectName=request.getParameter("projectName");
			String email=request.getParameter("email");
			String employee=request.getParameter("employee");
			String department=request.getParameter("department");
			String duration=request.getParameter("duration");
			String duration1=request.getParameter("duration1");
			String startDate=request.getParameter("startDate");
			String endDate=request.getParameter("endDate");
			String status=request.getParameter("pstatus");
			String grade=request.getParameter("grade");
			System.out.println(projectName+"  "+email+""+employee+""+department);
			Project_model m=new Project_model();
		
			
			m.setEname(employee);
			m.setPname(projectName);
			m.setDepartment(department);
			m.setDuration(duration);
			m.setStartDate(startDate);
			m.setEnddate(endDate);
		
			m.setGrade(grade);
			m.setAssigntime(duration1);
			
			
			
			
			
			m.setEmail(email);
			m.setStatus(status);
			
			
			datadao dao=new datadao();
		String f=	dao.update(m);
		
		
	//String g=	dao.report_insert(m);
			if(f.equals("done"))
			{
				
				
				RequestDispatcher rd=request.getRequestDispatcher("show_task");
				rd.forward(request, response);
				
				
			}
		}
		
		
		
		
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
