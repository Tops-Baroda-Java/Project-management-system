package com.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.datadao;
import com.model.department_insert;

public class department_entry extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		String dept_name=request.getParameter("deptName");
		String dept_design=request.getParameter("designation[0]");
		department_insert insert=new department_insert();
		
		insert.setDept_name(dept_name);
		insert.setDesignation(dept_design);
		
		datadao dao=new datadao();
		String model=	dao.dept(insert);
		
		if(model.equals("done"))
		{
			
	
			RequestDispatcher rd=request.getRequestDispatcher("show_dept");
			rd.forward(request, response);
			
			
		}
		
		doGet(request, response);
	}

}
