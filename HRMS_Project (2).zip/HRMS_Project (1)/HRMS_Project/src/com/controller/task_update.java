package com.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.datadao;
import com.model.Project_model;

/**
 * Servlet implementation class task_update
 */
public class task_update extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public task_update() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		

		String action=request.getParameter("action");
		if(action.equals("Pedit"))
		{
			
			String email=request.getParameter("Email");
			datadao dao=new datadao();
	Project_model m=		dao.task_update(email);
	
	Project_model m1=		dao.projectdata(email);
			request.setAttribute("task_update", m);
			request.setAttribute("task_up", m1);
			RequestDispatcher rd=request.getRequestDispatcher("task_verified.jsp");
			rd.forward(request, response);
			
		}}
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
