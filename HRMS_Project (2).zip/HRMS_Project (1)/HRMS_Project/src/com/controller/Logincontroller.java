package com.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.datadao;
import com.model.Loginmodel;

/**
 * Servlet implementation class Logincontroller
 */
public class Logincontroller extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Logincontroller() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		
		
		String action=request.getParameter("action");
		
		
		if(action.equals("edit"))
		{
			
			
			
			String userid=request.getParameter("userid");
			System.out.println(userid);
			
			datadao dao=new datadao();
		Loginmodel model=	dao.edit(Integer.parseInt(userid));
			
		
		request.setAttribute("editdata", model);
		
		RequestDispatcher rd=request.getRequestDispatcher("update1.jsp");
		rd.forward(request, response);
			
			
		}
		else if(action.equals("update"))
		{
			
			String Fname=request.getParameter("fullName");
			String fatherName=request.getParameter("fatherName");
			String date_of_birth=request.getParameter("date_of_birth");
			String gender=request.getParameter("gender");
			String mobileNumber=request.getParameter("mobileNumber");
			String id=request.getParameter("id");
			
			
			Loginmodel model = new Loginmodel();
			model.setName(Fname);
			model.setFather_name(fatherName);
			model.setDOB(date_of_birth);
			model.setGender(gender);
			model.setPhone(mobileNumber);
			model.setUserid(Integer.parseInt(id));
	
			datadao dao=new datadao();
		    String m=dao.update(model);
			if(m.equals("done"))
			{
				
				
				
				RequestDispatcher rd=request.getRequestDispatcher("showall");
				rd.forward(request, response);
			}
			
	
		}
		else
		{
			
			String userid=request.getParameter("userid");
			datadao  dao=new datadao();
		String s=	dao.delete(Integer.parseInt(userid));
			if(s.equals("done"))
			{
				
				
				RequestDispatcher rd=request.getRequestDispatcher("showall");
				rd.forward(request, response);
				
			}
			
		}
	}
	
	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		/*String Fname=request.getParameter("fullName");
		String fatherName=request.getParameter("fatherName");
		String date_of_birth=request.getParameter("date_of_birth");
		String gender=request.getParameter("gender");
		String mobileNumber=request.getParameter("mobileNumber");
		String localAddress=request.getParameter("localAddress");
		String PermanenAddress=request.getParameter("PermanentAddress");
		//String email=request.getParameter("email");
		//String oldpassword=request.getParameter("oldpassword");
		//String password=request.getParameter("password");
		String department=request.getParameter("department");
		String designation=request.getParameter("designation");
		String joiningDate=request.getParameter("joiningDate"); 
		String currentSalary=request.getParameter("currentSalary");
		String accountName=request.getParameter("accountName");
		String accountNumber=request.getParameter("accountNumber");
		String bank=request.getParameter("bank");
		String ifsc=request.getParameter("ifsc");
		String pan=request.getParameter("pan");
		String branch=request.getParameter("branch");
		
		Loginmodel model = new Loginmodel();
		model.setName(Fname);
		model.setFather_name(fatherName);
		model.setDOB(date_of_birth);
		model.setGender(gender);
		model.setPhone(mobileNumber);
		model.setLocal_Add(localAddress);
		model.setPer_Add(PermanenAddress);
		model.setC_department(department);
		model.setC_designation(designation);
		model.setC_DOB(joiningDate);
		model.setC_joining_Sal(currentSalary);
		model.setA_name(accountName);
		model.setB_ACC_Num(accountNumber);
		model.setB_Bank_nam(bank);
		model.setB_IFSC_code(ifsc);
		model.setB_PAN_Num(pan);
		model.setB_BRANCH(branch);
		
		datadao dao=new datadao();
		String s=dao.insert(model);
			
			if(s.equals("inserted"))
			{
				
				RequestDispatcher rd=request.getRequestDispatcher("create.jsp");
				rd.forward(request, response);
				
				
			}
			
			*/
		
		
		
		
		
		doGet(request, response);
	}

}
