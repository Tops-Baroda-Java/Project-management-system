package com.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.datadao;
import com.model.Loginmodel;

/**
 * Servlet implementation class insertservlet
 */
public class insertservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public insertservlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		
		
		String Fname=request.getParameter("fullName");
		String fatherName=request.getParameter("fatherName");
		String date_of_birth=request.getParameter("date_of_birth");
		String gender=request.getParameter("gender");
		String mobileNumber=request.getParameter("mobileNumber");
		String localAddress=request.getParameter("localAddress");
		String PermanenAddress=request.getParameter("permanentAddress");
		String email=request.getParameter("email");
		String password=request.getParameter("password");
		String department=request.getParameter("department");
		String designation=request.getParameter("designation");
		String joiningDate=request.getParameter("joiningDate"); 
		String currentSalary=request.getParameter("currentSalary");
		String accountName=request.getParameter("accountName");
		String accountNumber=request.getParameter("accountNumber");
		String bank=request.getParameter("bank");
		String ifsc=request.getParameter("ifsc");
		String pan=request.getParameter("pan");
		String branch=request.getParameter("branch");
		
		Loginmodel model = new Loginmodel();
		model.setName(Fname);
		model.setFather_name(fatherName);
		model.setDOB(date_of_birth);
		model.setGender(gender);
		model.setPhone(mobileNumber);
		model.setLocal_Add(localAddress);
		model.setPer_Add(PermanenAddress);
		model.setEmail_id(email);
		model.setAcc_pass(password);
		model.setC_department(department);
		model.setC_designation(designation);
		model.setC_DOB(joiningDate);
		model.setC_joining_Sal(currentSalary);
		model.setA_name(accountName);
		model.setB_ACC_Num(accountNumber);
		model.setB_Bank_nam(bank);
		model.setB_IFSC_code(ifsc);
		model.setB_PAN_Num(pan);
		model.setB_BRANCH(branch);
		
		datadao dao=new datadao();
		String s=dao.insert(model);
			
			if(s.equals("inserted"))
			{
				
				RequestDispatcher rd=request.getRequestDispatcher("create.jsp");
				rd.forward(request, response);
				
				
			}
	
		doGet(request, response);
	}

}
