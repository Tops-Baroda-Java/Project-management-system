package com.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.datadao;
import com.model.Project_model;

/**
 * Servlet implementation class user_task
 */
public class user_task extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public user_task() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		
		String action=request.getParameter("action");
		if(action.equals("edit"))
		{
			
			
			String email=request.getParameter("emailid");
			datadao dao=new datadao();
		Project_model m=	       dao.projectdata(email);
		
		
		request.setAttribute("taskdata", m);
		RequestDispatcher rd=request.getRequestDispatcher("user_task.jsp");
		rd.forward(request, response);
			
			
		}
		
		else if(action.equals("update"))
		{
			
			String email=request.getParameter("email");
			String duration=request.getParameter("duration");
			String sdtae=request.getParameter("startDate");
			String edtae=request.getParameter("endDate");
			
			
			
			
			Project_model m=new Project_model();
			m.setEmail(email);
			m.setDuration(duration);
			m.setStartDate(sdtae);
			m.setEnddate(edtae);
			
			
			
			datadao dao=new datadao();
		String d=	dao.usertask_update(m);
			if(d.equals("done"))
			{
				
				RequestDispatcher rd=request.getRequestDispatcher("report.jsp");
				rd.forward(request, response);
				
			}
			
			
			
			
		}
		
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
